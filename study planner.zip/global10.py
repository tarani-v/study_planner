from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

@app.route('/generate_schedule', methods=['POST'])
def generate_schedule():
    data = request.json
    subject = data.get('subject')
    time_available = data.get('time_available')

    if not subject or not time_available:
        return jsonify({'error': 'Subject and time available are required'}), 400

    # Example logic to generate a study schedule
    schedule = f"Study {subject} for {time_available} hours. Here's a suggested plan:\n\n"
    schedule += f"1. Spend {time_available * 0.4} hours on theory.\n"
    schedule += f"2. Spend {time_available * 0.3} hours on practice problems.\n"
    schedule += f"3. Spend {time_available * 0.2} hours on reviewing notes.\n"
    schedule += f"4. Spend {time_available * 0.1} hours on taking a short break."

    return jsonify({'schedule': schedule})

if __name__ == '__main__':
    app.run(debug=True)