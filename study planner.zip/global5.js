document.querySelector('.btn').addEventListener('click', function () {
    const subject = document.getElementById('subject').value;
    const timeAvailable = parseInt(document.getElementById('time').value);
  
    if (isNaN(timeAvailable) || timeAvailable <= 0) {
      alert("Please enter a valid time!");
      return;
    }
  
    const schedule = generateSchedule(subject, timeAvailable);
    alert(schedule);
  });
  
  function generateSchedule(subject, timeAvailable) {
    let schedule = `AI Study Schedule for ${subject} (Time: ${timeAvailable} hours):\n\n`;
  
    if (subject === "Mathematics") {
      if (timeAvailable >= 3) {
        schedule += `1. Review basic concepts (1 hour)\n2. Practice problems (1.5 hours)\n3. Advanced topics (0.5 hours)\n4. Break (0.5 hour)\n`;
      } else if (timeAvailable >= 2) {
        schedule += `1. Review basic concepts (1 hour)\n2. Practice problems (1 hour)\n`;
      } else {
        schedule += `1. Review basic concepts (1 hour)\n`;
      }
    } else if (subject === "Physics") {
      if (timeAvailable >= 3) {
        schedule += `1. Review theory (1 hour)\n2. Practice problems (1.5 hours)\n3. Experiment simulations (0.5 hours)\n`;
      } else if (timeAvailable >= 2) {
        schedule += `1. Review theory (1 hour)\n2. Practice problems (1 hour)\n`;
      } else {
        schedule += `1. Review theory (1 hour)\n`;
      }
    } else if (subject === "Chemistry") {
      if (timeAvailable >= 3) {
        schedule += `1. Review periodic table (1 hour)\n2. Organic chemistry (1 hour)\n3. Practice reactions (1 hour)\n`;
      } else if (timeAvailable >= 2) {
        schedule += `1. Review periodic table (1 hour)\n2. Organic chemistry (1 hour)\n`;
      } else {
        schedule += `1. Review periodic table (1 hour)\n`;
      }
    } else {
      schedule += `AI couldn't generate a study plan for this subject. Please select a valid subject.`;
    }
  
    return schedule;
  }
  