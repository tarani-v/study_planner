from flask import Flask, request, jsonify

app = Flask(__name__)

# Function to generate schedule based on subject and time available
def generate_schedule(subject, time_available):
    schedule = {"subject": subject, "schedule": ""}

    if subject == "Mathematics":
        if time_available >= 3:
            schedule["schedule"] = "1. Review basic concepts (1 hour)\n2. Practice problems (1.5 hours)\n3. Advanced topics (0.5 hours)\n4. Break (0.5 hour)"
        elif time_available >= 2:
            schedule["schedule"] = "1. Review basic concepts (1 hour)\n2. Practice problems (1 hour)"
        else:
            schedule["schedule"] = "1. Review basic concepts (1 hour)"

    elif subject == "Physics":
        if time_available >= 3:
            schedule["schedule"] = "1. Review theory (1 hour)\n2. Practice problems (1.5 hours)\n3. Experiment simulations (0.5 hours)"
        elif time_available >= 2:
            schedule["schedule"] = "1. Review theory (1 hour)\n2. Practice problems (1 hour)"
        else:
            schedule["schedule"] = "1. Review theory (1 hour)"

    elif subject == "Chemistry":
        if time_available >= 3:
            schedule["schedule"] = "1. Review periodic table (1 hour)\n2. Organic chemistry (1 hour)\n3. Practice reactions (1 hour)"
        elif time_available >= 2:
            schedule["schedule"] = "1. Review periodic table (1 hour)\n2. Organic chemistry (1 hour)"
        else:
            schedule["schedule"] = "1. Review periodic table (1 hour)"
    else:
        schedule["schedule"] = "AI couldn't generate a study plan for this subject. Please select a valid subject."

    return schedule

# Endpoint to generate study schedule
@app.route('/generate_schedule', methods=['POST'])
def generate_study_schedule():
    data = request.get_json()
    subject = data.get('subject')
    time_available = data.get('time_available')
    
    if not subject or time_available is None:
        return jsonify({"error": "Please provide both subject and time_available"}), 400
    
    schedule = generate_schedule(subject, time_available)
    return jsonify(schedule)

if __name__ == '__main__':
    app.run(debug=True)
