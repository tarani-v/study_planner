"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Trophy, Youtube, Clock, Sparkles, Flame, Star, Brain } from "lucide-react"

interface Task {
  id: number
  title: string
  duration: number
  completed: boolean
  resource?: string
  type?: "study" | "quiz"
  scheduledFor?: string
}

export default function StudyPlanner() {
  const [subject, setSubject] = useState("")
  const [timeLimit, setTimeLimit] = useState("")
  const [tasks, setTasks] = useState<Task[]>([])
  const [points, setPoints] = useState(0)
  const [showSchedule, setShowSchedule] = useState(false)
  const [currentStreak, setCurrentStreak] = useState(7)
  const [longestStreak, setLongestStreak] = useState(15)
  const [nextQuiz, setNextQuiz] = useState<string>(() => {
    const today = new Date()
    const next = new Date()
    next.setDate(today.getDate() + ((6 + 7 - today.getDay()) % 7)) // Next Saturday
    return next.toLocaleDateString("en-US", { weekday: "long", month: "short", day: "numeric" })
  })

  const generateSchedule = () => {
    if (!subject || !timeLimit) return

    const newTasks: Task[] = [
      {
        id: 1,
        title: "Review Core Concepts",
        duration: Number.parseFloat(timeLimit) * 60,
        completed: false,
        resource: "https://youtube.com/watch?v=example1",
        type: "study",
      },
      {
        id: 2,
        title: "Practice Problems",
        duration: Number.parseFloat(timeLimit) * 60,
        completed: false,
        type: "study",
      },
      {
        id: 3,
        title: "Watch Tutorial",
        duration: Number.parseFloat(timeLimit) * 60,
        completed: false,
        resource: "https://youtube.com/watch?v=example2",
        type: "study",
      },
      {
        id: 4,
        title: "Summary Notes",
        duration: Number.parseFloat(timeLimit) * 60,
        completed: false,
        type: "study",
      },
      {
        id: 5,
        title: `Weekly Quiz on ${subject}`,
        duration: 10,
        completed: false,
        type: "quiz",
        scheduledFor: nextQuiz,
      },
    ]
    setTasks(newTasks)
    setShowSchedule(true)
  }

  const toggleTask = (taskId: number) => {
    setTasks(
      tasks.map((task) => {
        if (task.id === taskId) {
          if (!task.completed) {
            setPoints((prev) => prev + 10)
          } else {
            setPoints((prev) => prev - 10)
          }
          return { ...task, completed: !task.completed }
        }
        return task
      }),
    )
  }

  const completedTasks = tasks.filter((task) => task.completed).length
  const progress = tasks.length ? (completedTasks / tasks.length) * 100 : 0

  return (
    <div className="min-h-screen butterfly-bg py-8">
      <div className="max-w-4xl mx-auto p-6 space-y-8">
        <div className="text-center space-y-2">
          <div className="flex items-center justify-center space-x-2">
            <Sparkles className="w-6 h-6 text-pink-400" />
            <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-pink-500 to-purple-500">
              AI: Unleashing Academic Potential
            </h1>
            <Sparkles className="w-6 h-6 text-pink-400" />
          </div>
          <p className="text-muted-foreground">Elevate your learning journey with AI</p>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-pink-600">Create Study Schedule</CardTitle>
              <CardDescription>Enter your study preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="subject">Subject</Label>
                <Select onValueChange={setSubject}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select subject" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="math">Mathematics</SelectItem>
                    <SelectItem value="science">Science</SelectItem>
                    <SelectItem value="history">History</SelectItem>
                    <SelectItem value="language">Language</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="timeLimit">Time Available (hours)</Label>
                <Input
                  id="timeLimit"
                  type="number"
                  min="0.5"
                  step="0.5"
                  placeholder="Enter time in hours"
                  value={timeLimit}
                  onChange={(e) => setTimeLimit(e.target.value)}
                />
              </div>
              <Button className="w-full" onClick={generateSchedule}>
                Generate Schedule
              </Button>
            </CardContent>
          </Card>

          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-pink-600">Your Stats</CardTitle>
              <CardDescription>Track your progress</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Trophy className="w-4 h-4 text-yellow-500" />
                  <span>Points:</span>
                </div>
                <span className="font-bold">{points}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Flame className="w-4 h-4 text-orange-500" />
                  <span>Current Streak:</span>
                </div>
                <div className="flex items-center space-x-1">
                  <span className="font-bold">{currentStreak}</span>
                  <span className="text-sm text-muted-foreground">days</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Star className="w-4 h-4 text-yellow-500" />
                  <span>Longest Streak:</span>
                </div>
                <div className="flex items-center space-x-1">
                  <span className="font-bold">{longestStreak}</span>
                  <span className="text-sm text-muted-foreground">days</span>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Progress</span>
                  <span>{Math.round(progress)}%</span>
                </div>
                <Progress value={progress} />
              </div>
            </CardContent>
          </Card>
        </div>

        {showSchedule && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-pink-600">Your Study Schedule</h2>
            <div className="grid gap-4">
              {tasks.map((task) => (
                <Card
                  key={task.id}
                  className={`glass-card transition-all duration-300 hover:shadow-lg ${
                    task.completed ? "bg-pink-50/50" : ""
                  }`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <Checkbox checked={task.completed} onCheckedChange={() => toggleTask(task.id)} />
                        <div>
                          <p className="font-medium">{task.title}</p>
                          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                            <Clock className="w-4 h-4" />
                            <span>
                              {task.duration >= 60
                                ? `${(task.duration / 60).toFixed(1)} hours`
                                : `${task.duration} mins`}
                            </span>
                          </div>
                        </div>
                      </div>
                      {task.resource && (
                        <Button variant="outline" size="sm" className="flex items-center space-x-2">
                          <Youtube className="w-4 h-4" />
                          <span>Watch</span>
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {showSchedule && tasks.some((task) => task.type === "quiz") && (
          <Card className="glass-card border-pink-200">
            <CardHeader>
              <CardTitle className="text-pink-600 flex items-center gap-2">
                <Brain className="w-5 h-5" />
                Upcoming Quiz
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Weekly {subject} Quiz</p>
                    <p className="text-sm text-muted-foreground">Scheduled for {nextQuiz}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">10 mins</span>
                  </div>
                </div>
                <div className="text-sm text-muted-foreground">
                  Complete your weekly quiz to maintain your streak and earn bonus points!
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-pink-600">Leaderboard</CardTitle>
            <CardDescription>Top performers this week</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="bg-gradient-to-r from-pink-400 to-purple-400 text-white w-8 h-8 rounded-full flex items-center justify-center">
                    1
                  </div>
                  <div>
                    <p className="font-medium">Alex M.</p>
                    <p className="text-sm text-muted-foreground">500 points</p>
                  </div>
                </div>
                <Trophy className="w-5 h-5 text-pink-400" />
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="bg-gradient-to-r from-pink-300 to-purple-300 text-white w-8 h-8 rounded-full flex items-center justify-center">
                    2
                  </div>
                  <div>
                    <p className="font-medium">Sarah K.</p>
                    <p className="text-sm text-muted-foreground">450 points</p>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="bg-gradient-to-r from-pink-200 to-purple-200 text-white w-8 h-8 rounded-full flex items-center justify-center">
                    3
                  </div>
                  <div>
                    <p className="font-medium">John D.</p>
                    <p className="text-sm text-muted-foreground">400 points</p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        <div className="mt-4">
          <div className="text-sm font-medium mb-2">Streak Calendar</div>
          <div className="grid grid-cols-7 gap-1">
            {Array.from({ length: 7 }).map((_, i) => (
              <div
                key={i}
                className={`h-8 rounded-md flex items-center justify-center text-xs ${
                  i < 7 ? "bg-gradient-to-r from-pink-400 to-purple-400 text-white" : "bg-muted"
                }`}
              >
                {i < 7 && <Flame className="w-3 h-3" />}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

